<template>
  <Form />
</template>

<script setup lang="ts">
import Form from './components/Form.vue';
</script>

<style>
* {
  box-sizing: border-box;
}

html {
  font-family: sans-serif;
}

body {
  margin: 0;
  background-color: #292929;
}
</style>